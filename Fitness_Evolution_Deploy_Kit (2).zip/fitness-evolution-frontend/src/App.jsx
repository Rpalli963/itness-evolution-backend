import React, { useEffect, useMemo, useState } from 'react'

const API_URL = import.meta.env.VITE_API_URL || 'http://127.0.0.1:8000'
const USER_ID = 1

async function apiRegisterDay(payload) {
  const res = await fetch(`${API_URL}/register-day/`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  })
  if (!res.ok) throw new Error('Falha ao registrar dia')
  return res.json()
}
async function apiGetProgress(userId) {
  const res = await fetch(`${API_URL}/progress/${userId}`)
  if (!res.ok) throw new Error('Falha ao buscar progresso')
  return res.json()
}
async function apiGetHistory(userId) {
  const res = await fetch(`${API_URL}/history/${userId}`)
  if (!res.ok) throw new Error('Falha ao buscar histórico')
  return res.json()
}

function Card({ children }) {
  return <div style={{background:'#fff',borderRadius:16,boxShadow:'0 6px 16px rgba(0,0,0,0.08)',padding:20}}>{children}</div>
}
function ProgressBar({ points }) {
  const pct = Math.max(0, Math.min(1, (points ?? 0) / 30))
  const color = pct >= 0.8 ? '#22c55e' : pct >= 0.5 ? '#f59e0b' : '#ef4444'
  return (
    <div>
      <div style={{display:'flex',justifyContent:'space-between',marginBottom:6}}>
        <span style={{fontSize:12,color:'#334155'}}>Evolução semanal</span>
        <span style={{fontSize:12,color:'#64748b'}}>{points ?? 0} pts</span>
      </div>
      <div style={{height:12, background:'#e2e8f0', borderRadius:999, overflow:'hidden'}}>
        <div style={{height:'100%', width:`${pct*100}%`, background:color, transition:'width .6s'}} />
      </div>
    </div>
  )
}
function BadgeLevel({ label }) {
  return <span style={{fontSize:12, background:'#e2e8f0', color:'#0f172a', padding:'6px 10px', borderRadius:999}}>{label || 'Iniciante'}</span>
}

function formatDateISO(date) {
  const d = new Date(date)
  const year = d.getFullYear()
  const month = `${d.getMonth()+1}`.padStart(2,'0')
  const day = `${d.getDate()}`.padStart(2,'0')
  return `${year}-${month}-${day}`
}

function useProgress(userId) {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [data, setData] = useState({ semana:'', pontos_totais:0, nivel_semana:'' })
  const refresh = async () => {
    try { setLoading(true); const d = await apiGetProgress(userId); setData(d); setError(null) }
    catch(e){ setError(e.message) } finally { setLoading(false) }
  }
  useEffect(()=>{ refresh() }, [userId])
  return { loading, error, data, refresh }
}
function useHistory(userId) {
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState(null)
  const [data, setData] = useState([])
  const refresh = async () => {
    try { setLoading(true); const d = await apiGetHistory(userId); setData(d||[]); setError(null) }
    catch(e){ setError(e.message) } finally { setLoading(false) }
  }
  useEffect(()=>{ refresh() }, [userId])
  return { loading, error, data, refresh }
}

function LogForm({ onSubmitted }) {
  const [date, setDate] = useState(formatDateISO(new Date()))
  const [treino, setTreino] = useState(true)
  const [hidratacao, setHidratacao] = useState(2)
  const [alimentacao, setAlimentacao] = useState(1)
  const [sono, setSono] = useState(7)
  const [alcool, setAlcool] = useState(false)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')
  async function handleSubmit(e){
    e.preventDefault();
    setSaving(true); setMsg('');
    try {
      const payload = {
        user_id: USER_ID,
        data: date,
        treino,
        hidratacao: Number(hidratacao),
        alimentacao: Number(alimentacao),
        sono_horas: Number(sono),
        alcool,
      };
      const res = await apiRegisterDay(payload);
      setMsg(`Dia registrado! Pontos: ${res.pontos_dia ?? res.pontos ?? 'ok'}`);
      onSubmitted?.();
    } catch (err) {
      setMsg('Erro ao registrar dia.');
    } finally {
      setSaving(false);
    }
  }
  return (
    <Card>
      <h2 style={{fontSize:18, fontWeight:600, marginBottom:12}}>Registrar hábitos do dia</h2>
      <form onSubmit={handleSubmit} style={{display:'grid', gridTemplateColumns:'1fr 1fr', gap:12}}>
        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <label style={{fontSize:12,color:'#334155'}}>Data</label>
          <input type="date" value={date} onChange={e=>setDate(e.target.value)} style={{border:'1px solid #cbd5e1',borderRadius:12,padding:'8px 12px'}} required />
        </div>

        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', border:'1px solid #cbd5e1', borderRadius:12, padding:'8px 12px'}}>
          <label style={{fontSize:12,color:'#334155'}}>Treino concluído</label>
          <input type="checkbox" checked={treino} onChange={e=>setTreino(e.target.checked)} />
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <label style={{fontSize:12,color:'#334155'}}>Hidratação</label>
          <select value={hidratacao} onChange={e=>setHidratacao(e.target.value)} style={{border:'1px solid #cbd5e1',borderRadius:12,padding:'8px 12px'}}>
            <option value={2}>Meta atingida (+3)</option>
            <option value={1}>Parcial (0)</option>
            <option value={0}>Não atingida (-1)</option>
          </select>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <label style={{fontSize:12,color:'#334155'}}>Alimentação</label>
          <select value={alimentacao} onChange={e=>setAlimentacao(e.target.value)} style={{border:'1px solid #cbd5e1',borderRadius:12,padding:'8px 12px'}}>
            <option value={1}>Boa (+3)</option>
            <option value={0}>Regular (0)</option>
            <option value={-1}>Ruim/Álcool (-3)</option>
          </select>
        </div>

        <div style={{display:'flex', flexDirection:'column', gap:6}}>
          <label style={{fontSize:12,color:'#334155'}}>Sono (horas)</label>
          <input type="number" min={0} max={24} value={sono} onChange={e=>setSono(e.target.value)} style={{border:'1px solid #cbd5e1',borderRadius:12,padding:'8px 12px'}} />
        </div>

        <div style={{display:'flex', alignItems:'center', justifyContent:'space-between', border:'1px solid #cbd5e1', borderRadius:12, padding:'8px 12px'}}>
          <label style={{fontSize:12,color:'#334155'}}>Bebeu álcool?</label>
          <input type="checkbox" checked={alcool} onChange={e=>setAlcool(e.target.checked)} />
        </div>

        <div style={{gridColumn:'1 / -1', display:'flex', alignItems:'center', gap:12}}>
          <button disabled={saving} style={{padding:'10px 16px', borderRadius:12, background:'#0f172a', color:'#fff', border:'none', cursor:'pointer', opacity:saving?0.7:1}}>
            {saving ? 'Salvando...' : 'Salvar dia'}
          </button>
          {msg && <span style={{fontSize:12, color:'#334155'}}>{msg}</span>}
        </div>
      </form>
    </Card>
  );
}

function HistoryList({ items }) {
  if (!items?.length) return <Card><p style={{fontSize:14,color:'#475569'}}>Sem registros ainda. Comece hoje! 💪</p></Card>
  return (
    <Card>
      <h2 style={{fontSize:18, fontWeight:600, marginBottom:12}}>Histórico recente</h2>
      <div>
        {items.map((l) => (
          <div key={l.id ?? `${l.data}-${l.pontos_dia}`} style={{display:'flex', justifyContent:'space-between', border:'1px solid #e2e8f0', borderRadius:12, padding:'8px 12px', marginBottom:8}}>
            <div style={{fontSize:12,color:'#334155'}}>
              <div style={{fontWeight:600,color:'#0f172a'}}>{l.data}</div>
              <div>Treino: {l.treino ? 'Sim' : 'Não'} • Hidratação: {l.hidratacao} • Alimentação: {l.alimentacao} • Sono: {l.sono_horas}h • Álcool: {l.alcool ? 'Sim' : 'Não'}</div>
            </div>
            <div style={{fontWeight:700, color:'#0f172a'}}>{l.pontos_dia} pts</div>
          </div>
        ))}
      </div>
    </Card>
  )
}

export default function App() {
  const [progress, setProgress] = useState({ semana:'', pontos_totais:0, nivel_semana:'Iniciante' })
  const [history, setHistory] = useState([])
  const [loading, setLoading] = useState(true)

  async function refreshAll() {
    try {
      setLoading(true);
      const p = await apiGetProgress(USER_ID);
      const h = await apiGetHistory(USER_ID);
      setProgress(p); setHistory(h);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }
}

  useEffect(() => { refreshAll() }, [])

  return (
    <div style={{minHeight:'100vh', background:'#f1f5f9'}}>
      <header style={{padding:'16px 24px', borderBottom:'1px solid #e2e8f0', background:'#fff', position:'sticky', top:0, zIndex:10}}>
        <div style={{maxWidth:1100, margin:'0 auto'}}>
          <h1 style={{fontSize:24, fontWeight:800}}>Fitness Evolution</h1>
          <p style={{fontSize:12, color:'#64748b', marginTop:6}}>
            {progress?.semana ? `Semana ${progress.semana} • Nível: ${progress.nivel_semana}` : 'Registre seu primeiro dia para começar.'}
          </p>
        </div>
      </header>

      <main style={{maxWidth:1100, margin:'0 auto', padding:'24px'}}>
        <div style={{display:'grid', gridTemplateColumns:'2fr 1fr', gap:24}}>
          <Card>
            <div style={{display:'flex', alignItems:'center', justifyContent:'space-between'}}>
              <ProgressBar points={progress?.pontos_totais || 0} />
              <BadgeLevel label={progress?.nivel_semana || 'Iniciante'} />
            </div>
            {loading && <div style={{fontSize:12, color:'#64748b', marginTop:8}}>Carregando...</div>}
          </Card>
          <LogForm onSubmitted={refreshAll} />
        </div>

        <div style={{marginTop:24}}>
          <HistoryList items={history} />
        </div>

        <footer style={{textAlign:'center', fontSize:12, color:'#94a3b8', padding:'24px 0'}}>Feito com 💪 saúde, foco e consistência.</footer>
      </main>
    </div>
  )
}
