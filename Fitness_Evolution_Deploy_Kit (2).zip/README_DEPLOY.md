# Fitness Evolution — Deployment Kit (GitHub + Render + Vercel)

## Backend (FastAPI)
- Deploy automático com `render.yaml`
- Porta: 10000
- Docs: `/docs`

## Frontend (Vite + React)
- Variável: `VITE_API_URL` para apontar o backend
- `vercel.json` incluso

## Passos rápidos
1. Crie 2 repositórios vazios no GitHub: `fitness-evolution-backend` e `fitness-evolution-frontend`
2. Suba o conteúdo das respectivas pastas
3. Render: New → Web Service → conecte o repo backend (usa `render.yaml`)
4. Vercel: New Project → conecte o repo frontend → defina `VITE_API_URL` se quiser trocar
