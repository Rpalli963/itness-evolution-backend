from fastapi import FastAPI, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List
from .database import SessionLocal, engine, Base
from . import models, schemas, crud

Base.metadata.create_all(bind=engine)

app = FastAPI(title="Fitness Evolution API")


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/users/", response_model=schemas.UserOut)
def create_user(user: schemas.UserCreate, db: Session = Depends(get_db)):
    return crud.create_user(db, nome=user.nome, email=user.email)

@app.post("/register-day/", response_model=schemas.DailyLogOut)
def register_day(log: schemas.DailyLogCreate, db: Session = Depends(get_db)):
    user = crud.get_user(db, log.user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    db_log = crud.create_daily_log(db, log)
    return db_log

@app.get("/history/{user_id}", response_model=List[schemas.DailyLogOut])
def get_history(user_id: int, db: Session = Depends(get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return crud.get_daily_logs_for_user(db, user_id, limit=30)

@app.get("/progress/{user_id}", response_model=schemas.WeeklyProgressOut)
def get_progress(user_id: int, db: Session = Depends(get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    data = crud.get_weekly_progress_data(db, user_id)
    if not data:
        raise HTTPException(status_code=404, detail="No progress found")
    return data

@app.post("/send-report/{user_id}")
def send_report(user_id: int, db: Session = Depends(get_db)):
    user = crud.get_user(db, user_id)
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    logs = crud.get_daily_logs_for_user(db, user_id, limit=7)
    progress = crud.get_weekly_progress_data(db, user_id) or {}
    return {"status": "report_compiled", "user_id": user_id, "progress": progress, "last_days": [l.__dict__ for l in logs]}
