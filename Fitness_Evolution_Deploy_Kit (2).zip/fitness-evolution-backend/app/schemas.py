from pydantic import BaseModel
from typing import Optional, List

class UserCreate(BaseModel):
    nome: str
    email: Optional[str] = None

class UserOut(BaseModel):
    id: int
    nome: str
    email: Optional[str] = None
    class Config:
        orm_mode = True

class DailyLogCreate(BaseModel):
    user_id: int
    data: str  # 'YYYY-MM-DD'
    treino: bool
    hidratacao: int  # 0/1/2
    alimentacao: int  # -1/0/1
    sono_horas: int
    alcool: bool

class DailyLogOut(DailyLogCreate):
    id: int
    pontos_dia: int
    class Config:
        orm_mode = True

class WeeklyProgressOut(BaseModel):
    semana: str
    pontos_totais: int
    nivel_semana: str
    class Config:
        orm_mode = True
