from datetime import datetime

def calculate_daily_points(treino: bool, hidratacao: int, alimentacao: int, sono_horas: int, alcool: bool) -> int:
    points = 0
    points += 5 if treino else 0
    points += 3 if hidratacao >= 2 else (-1 if hidratacao == 0 else 0)
    if alimentacao == 1:
        points += 3
    elif alimentacao == -1:
        points -= 3
    if 7 <= sono_horas <= 8:
        points += 2
    elif sono_horas == 6:
        points += 1
    elif sono_horas < 6:
        points -= 2
    if alcool:
        points -= 3
    if not treino:
        points -= 5
    return points

def get_week_identifier(date_str: str) -> str:
    dt = datetime.fromisoformat(date_str)
    year, week, _ = dt.isocalendar()
    return f"{year}-W{week}"

def map_week_points_to_level(points_week: int) -> str:
    if points_week <= 10:
        return "Iniciante"
    if 11 <= points_week <= 20:
        return "Em Progresso"
    if 21 <= points_week <= 30:
        return "Determinado"
    return "Atleta da Vida"
