from sqlalchemy.orm import Session
from . import models, schemas, utils

def create_user(db: Session, nome: str, email: str = None):
    user = models.User(nome=nome, email=email)
    db.add(user)
    db.commit()
    db.refresh(user)
    return user

def get_user(db: Session, user_id: int):
    return db.query(models.User).filter(models.User.id == user_id).first()

def create_daily_log(db: Session, log: schemas.DailyLogCreate):
    pontos = utils.calculate_daily_points(log.treino, log.hidratacao, log.alimentacao, log.sono_horas, log.alcool)
    db_log = models.DailyLog(
        user_id=log.user_id,
        data=log.data,
        treino=log.treino,
        hidratacao=log.hidratacao,
        alimentacao=log.alimentacao,
        sono_horas=log.sono_horas,
        alcool=log.alcool,
        pontos_dia=pontos
    )
    db.add(db_log)
    db.commit()
    db.refresh(db_log)
    return db_log

def get_daily_logs_for_user(db: Session, user_id: int, limit: int = 30):
    return db.query(models.DailyLog).filter(models.DailyLog.user_id == user_id).order_by(models.DailyLog.data.desc()).limit(limit).all()

def get_weekly_progress_data(db: Session, user_id: int):
    logs = db.query(models.DailyLog).filter(models.DailyLog.user_id == user_id).all()
    # somar apenas semana atual (ISO)
    from .utils import get_week_identifier, map_week_points_to_level
    if not logs:
        return None
    current_week = None
    from datetime import datetime
    today = datetime.today().strftime("%Y-%m-%d")
    current_week = get_week_identifier(today)
    total = sum(l.pontos_dia for l in logs if get_week_identifier(l.data) == current_week)
    nivel = map_week_points_to_level(total)
    return {"semana": current_week, "pontos_totais": total, "nivel_semana": nivel}
